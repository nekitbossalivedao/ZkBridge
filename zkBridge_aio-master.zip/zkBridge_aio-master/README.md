<h1 align="center">zkBridge aio</h1>

<h2>О боте</h2>
Бот для минта&бриджа нфт и отправки сообщений через https://zkbridge.com/</br>


* Настройки и инструкция в config.py ЧИТАЕМ ОБЯЗАТЕЛЬНО

* Приватные кошельки пишем в keys.txt - один ключ на одной строке </br>

* Прокси в proxyy.txt - один прокси на одной строке  в формате login:pass@ip:port</br>

* login:pass@ip:port</br>

* Необходим апи ключ моралис - https://admin.moralis.io/settings#secret-keys
 </br>

* Также не забудьте установить зависимости 

<pre><code>$ pip install -r requirements.txt</code></pre>


<h2>Режимы работы</h2>

1. Минт&бридж новых нфт и бридж УЖЕ ЗАМИНЧЕННЫХ И КОГДА ТО ЗАБРИДЖЕННЫХ НФТ</br>
2. Отправка сообщений


<h2>донат</h2> 0xFD6594D11b13C6b1756E328cc13aC26742dBa868
<h2>тг</h2> https://t.me/iliocka
